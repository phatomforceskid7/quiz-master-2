import firebase from 'firebase';

 const firebaseConfig = {
    apiKey: "AIzaSyBRsunNnz4nACLt38kb2hIDSau9YMIuXTo",
    authDomain: "wireless-buzzer-app-8e8f3.firebaseapp.com",
    databaseURL: "https://wireless-buzzer-app-8e8f3-default-rtdb.firebaseio.com",
    projectId: "wireless-buzzer-app-8e8f3",
    storageBucket: "wireless-buzzer-app-8e8f3.appspot.com",
    messagingSenderId: "936707492353",
    appId: "1:936707492353:web:29a4996849587df0b10e00",
    measurementId: "G-0R5JS3XL8N"
  };

// Initialize Firebase
if(!firebase.apps.length){
  firebase.initializeApp(firebaseConfig);
} 


  export default firebase.database();
